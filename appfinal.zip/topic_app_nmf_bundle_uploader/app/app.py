import re
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Optional libs
try:
    from underthesea import word_tokenize
    UNDERTHESEA_OK = True
except Exception:
    UNDERTHESEA_OK = False

try:
    from wordcloud import WordCloud
    WORDCLOUD_OK = True
except Exception:
    WORDCLOUD_OK = False


st.set_page_config(page_title="NMF Topic Explorer + Recommender", layout="wide")
DEFAULT_CSV = "data_sample/sample_data_for_nmf_app.csv"

# -------------------------
# Helpers
# -------------------------
def infer_source(url: str) -> str:
    if not isinstance(url, str):
        return "Unknown"
    if "vnexpress.net" in url:
        return "VnExpress"
    if "dantri.com.vn" in url:
        return "Dân Trí"
    if "vietnamnet.vn" in url:
        return "VietnamNet"
    m = re.search(r"https?://([^/]+)/", url)
    return m.group(1) if m else "Unknown"

def clean_text_basic(s: str) -> str:
    s = str(s).lower()
    s = re.sub(r"\s+", " ", s).strip()
    return s

def to_tokenized_text(raw: str) -> str:
    """Tokenize Vietnamese raw text into underthesea-like tokens if available."""
    raw = clean_text_basic(raw)
    if UNDERTHESEA_OK:
        tok = word_tokenize(raw, format="text") 
        tok = re.sub(r"[^\w\s_]", " ", tok)
        tok = re.sub(r"\s+", " ", tok).strip()
        return tok
    raw = re.sub(r"[^\w\s_]", " ", raw)
    raw = re.sub(r"\s+", " ", raw).strip()
    return raw

def make_wordcloud(texts: list[str]):
    if not WORDCLOUD_OK:
        return None
    text = " ".join([t for t in texts if isinstance(t, str)])
    if not text.strip():
        return None
    wc = WordCloud(width=1000, height=420, background_color="white", collocations=False)
    wc.generate(text)
    return wc.to_array()

def normalize_rows(W: np.ndarray):
    s = W.sum(axis=1, keepdims=True)
    s[s == 0] = 1.0
    return W / s

def get_top_words(nmf_model: NMF, feature_names: np.ndarray, topn: int = 15):
    topics = []
    for k in range(nmf_model.n_components):
        idx = np.argsort(nmf_model.components_[k])[::-1][:topn]
        topics.append(feature_names[idx].tolist())
    return topics

# -------------------------
# Data + Model cache
# -------------------------
@st.cache_data
def load_data(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    if "source" not in df.columns and "url" in df.columns:
        df["source"] = df["url"].apply(infer_source)
    if "publish_date" in df.columns:
        df["publish_date_dt"] = pd.to_datetime(df["publish_date"], dayfirst=True, errors="coerce")
    else:
        df["publish_date_dt"] = pd.NaT
    return df

@st.cache_resource
def fit_vectorizer_and_nmf(texts: pd.Series, n_topics: int, max_features: int, ngram_max: int):
    vec = TfidfVectorizer(
        token_pattern=r"(?u)\b\w+\b",
        lowercase=False,
        max_df=0.9,
        min_df=5,
        max_features=max_features,
        ngram_range=(1, ngram_max),
    )
    X = vec.fit_transform(texts.fillna("").astype(str))

    nmf = NMF(
        n_components=n_topics,
        random_state=42,
        init="nndsvd",
        max_iter=300,
    )
    W = nmf.fit_transform(X)
    return vec, X, nmf, W

# -------------------------
# UI
# -------------------------
st.title("NMF Topic Modeling Explorer")

with st.sidebar:
    st.header("📄 Dữ liệu")
    uploaded_file = st.file_uploader("Thả file CSV vào đây", type=["csv"])
    csv_path = st.text_input("Hoặc nhập đường dẫn CSV", value=DEFAULT_CSV)

    st.divider()
    st.header(" Cấu hình NMF")
    n_topics = st.slider("Số topic (k)", 3, 20, 5)
    max_features = st.select_slider("max_features (TF-IDF)", options=[3000, 5000, 8000, 12000], value=5000)
    ngram_max = st.select_slider("ngram_range max", options=[1, 2], value=2)
    topn_words = st.slider("Top words / topic", 10, 30, 15)

    st.divider()
    st.header(" Recommender")
    topn_rec = st.slider("Top N bài gợi ý", 3, 15, 5)
    restrict_same_topic = st.checkbox("Chỉ gợi ý trong cùng topic", value=True)

    st.divider()
    st.caption("Nên test bằng **title + content**, không chỉ tiêu đề.")

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    # chuẩn hóa giống load_data()
    if "source" not in df.columns and "url" in df.columns:
        df["source"] = df["url"].apply(infer_source)
    if "publish_date" in df.columns:
        df["publish_date_dt"] = pd.to_datetime(df["publish_date"], dayfirst=True, errors="coerce")
    else:
        df["publish_date_dt"] = pd.NaT
else:
    df = load_data(csv_path)

need_cols = ["title", "url", "text_tfidf"]
missing = [c for c in need_cols if c not in df.columns]
if missing:
    st.error(f"CSV thiếu cột: {missing}. Tối thiểu cần title, url, text_tfidf.")
    st.stop()

# Filters (Explorer)
st.subheader("Bộ lọc dữ liệu (Explorer)")
c1, c2, c3, c4 = st.columns([1.1, 1.2, 1.6, 1.3])

with c1:
    sources = sorted(df["source"].dropna().unique()) if "source" in df.columns else []
    src_sel = st.multiselect("Source", sources, default=sources)

with c2:
    cats = sorted(df["category"].dropna().unique()) if "category" in df.columns else []
    cat_sel = st.multiselect("Category", cats, default=cats)

with c3:
    keyword = st.text_input("Keyword lọc title", value="").strip().lower()

with c4:
    if df["publish_date_dt"].notna().any():
        dmin = df["publish_date_dt"].min().date()
        dmax = df["publish_date_dt"].max().date()
        date_range = st.date_input("Date range", value=(dmin, dmax))
    else:
        date_range = None
        st.info("Không có/không parse được publish_date → bỏ lọc theo ngày.")

df_f = df.copy()
if "source" in df_f.columns and src_sel:
    df_f = df_f[df_f["source"].isin(src_sel)]
if "category" in df_f.columns and cat_sel:
    df_f = df_f[df_f["category"].isin(cat_sel)]
if keyword:
    df_f = df_f[df_f["title"].astype(str).str.lower().str.contains(keyword, na=False)]
if date_range and isinstance(date_range, tuple) and len(date_range) == 2 and df_f["publish_date_dt"].notna().any():
    start, end = date_range
    df_f = df_f[(df_f["publish_date_dt"].dt.date >= start) & (df_f["publish_date_dt"].dt.date <= end)]

st.caption(f"Số bài sau lọc: **{len(df_f):,}**")

# Fit NMF on filtered set
with st.spinner("Đang fit TF-IDF + NMF (lần đầu có thể mất vài giây)..."):
    vec, X, nmf, W = fit_vectorizer_and_nmf(df_f["text_tfidf"], n_topics, max_features, ngram_max)
    Wn = normalize_rows(W)
    feature_names = np.array(vec.get_feature_names_out())
    topic_words = get_top_words(nmf, feature_names, topn=topn_words)

df_f = df_f.reset_index(drop=True)
df_f["nmf_topic"] = W.argmax(axis=1)
df_f["nmf_topic_score"] = Wn.max(axis=1)

# -------------------------
# Explorer
# -------------------------
st.divider()
st.subheader(" Phân bố số bài theo topic (NMF)")
topic_counts = df_f["nmf_topic"].value_counts().sort_index().reset_index()
topic_counts.columns = ["topic", "count"]
st.plotly_chart(px.bar(topic_counts, x="topic", y="count"), use_container_width=True)

st.subheader("🔎 Click 1 topic để xem chi tiết")
topic_sel = st.selectbox("Chọn topic", sorted(df_f["nmf_topic"].unique()))
df_t = df_f[df_f["nmf_topic"] == topic_sel].copy()

colA, colB = st.columns([1.2, 1])
with colA:
    st.markdown(f"### Topic {topic_sel}")
    st.write("**Top words:**", ", ".join(topic_words[int(topic_sel)][:topn_words]))
    st.write(f"**Số bài (sau lọc):** {len(df_t):,}")
with colB:
    st.write("**WordCloud (từ text_tfidf trong topic)**")
    img = make_wordcloud(df_t["text_tfidf"].astype(str).tolist())
    if img is not None:
        st.image(img, use_container_width=True)
    else:
        st.info("Không tạo được wordcloud (thiếu thư viện hoặc thiếu dữ liệu).")

st.write("**Top 5 bài đại diện (topic score cao nhất):**")
rep = df_t.sort_values("nmf_topic_score", ascending=False).head(5)
cols_show = [c for c in ["publish_date", "source", "category", "title", "url", "nmf_topic_score"] if c in rep.columns]
st.dataframe(rep[cols_show], use_container_width=True, hide_index=True)

# -------------------------
# CHUC NANG
# -------------------------
st.divider()
tab1, tab2 = st.tabs(["Gán topic cho bài mới", "Gợi ý bài tương tự"])

with tab1:
    st.markdown("### Nhập bài mới để gán topic (NMF)")
    raw = st.text_area("Dán tiêu đề + nội dung", height=200)
    if st.button("Gán topic & gợi ý"):
        if len(raw.strip()) < 50:
            st.warning("Nội dung quá ngắn. Nên dán cả tiêu đề + vài đoạn nội dung để gán topic ổn hơn.")
        tokenized = to_tokenized_text(raw)
        qX = vec.transform([tokenized])
        qW = nmf.transform(qX)
        qWn = normalize_rows(qW)
        top3 = np.argsort(qWn.ravel())[::-1][:3]

        st.markdown("#### Kết quả gán topic")
        st.write("**Top 3 topic:**")
        for t in top3:
            st.write(f"- Topic {int(t)} | score = {float(qWn.ravel()[t]):.4f} | top words: {', '.join(topic_words[int(t)][:10])}")

        best_t = int(top3[0])
        st.markdown(f"#### Topic dự đoán: **{best_t}**")
        st.write("**Top words:**", ", ".join(topic_words[best_t][:topn_words]))

        if restrict_same_topic:
            pool = df_f[df_f["nmf_topic"] == best_t].copy()
            X_pool = X[pool.index]
            sims = cosine_similarity(qX, X_pool).ravel()
            idxs = np.argsort(-sims)[:topn_rec]
            rec = pool.iloc[idxs].copy()
            rec["similarity"] = sims[idxs]
        else:
            sims = cosine_similarity(qX, X).ravel()
            idxs = np.argsort(-sims)[:topn_rec]
            rec = df_f.iloc[idxs].copy()
            rec["similarity"] = sims[idxs]

        st.markdown("#### Top bài tương tự")
        cols = [c for c in ["similarity","nmf_topic","publish_date","source","category","title","url"] if c in rec.columns]
        st.dataframe(rec[cols].sort_values("similarity", ascending=False), use_container_width=True, hide_index=True)

with tab2:
    st.markdown("### Chọn 1 bài trong kho để gợi ý bài tương tự")
    q = st.text_input("Tìm bài theo title", value="")
    cand = df_f
    if q.strip():
        cand = df_f[df_f["title"].astype(str).str.lower().str.contains(q.strip().lower(), na=False)]
    cand = cand.head(250)

    if len(cand) == 0:
        st.info("Không tìm thấy bài phù hợp.")
    else:
        sel = st.selectbox("Chọn bài làm truy vấn", cand["title"].astype(str).tolist(), index=0)
        row = cand[cand["title"].astype(str) == sel].iloc[0]
        pos = row.name

        qX = X[pos]
        q_topic = int(df_f.loc[pos, "nmf_topic"])

        st.write("**Bài truy vấn:**", row["title"])
        st.write("**Topic:**", q_topic)
        st.write("**URL:**", row["url"])

        if restrict_same_topic:
            pool = df_f[df_f["nmf_topic"] == q_topic].copy()
            X_pool = X[pool.index]
            sims = cosine_similarity(qX, X_pool).ravel()
            idxs = np.argsort(-sims)[:topn_rec+1]
            rec = pool.iloc[idxs].copy()
            rec["similarity"] = sims[idxs]
            rec = rec[rec["url"] != row["url"]].head(topn_rec)
        else:
            sims = cosine_similarity(qX, X).ravel()
            sims[pos] = -1.0
            idxs = np.argsort(-sims)[:topn_rec]
            rec = df_f.iloc[idxs].copy()
            rec["similarity"] = sims[idxs]

        cols = [c for c in ["similarity","nmf_topic","publish_date","source","category","title","url"] if c in rec.columns]
        st.dataframe(rec[cols].sort_values("similarity", ascending=False), use_container_width=True, hide_index=True)

        st.plotly_chart(px.bar(rec.sort_values("similarity", ascending=True),
                               x="similarity", y="title", orientation="h"),
                        use_container_width=True)

# NMF Topic Explorer + Recommender (Bundle)

Gồm:
- `app/app.py`: Streamlit app (Explorer + Option 1 + Option 3) chạy theo NMF
- `requirements.txt`
- `data_sample/sample_data_for_nmf_app.csv`: file mẫu để test

## Cách chạy
```bash
python -m pip install -r requirements.txt
python -m streamlit run app/app.py
```

## Dữ liệu đầu vào
CSV tối thiểu cần có: `title`, `url`, `text_tfidf`  
Khuyến nghị thêm: `publish_date`, `category`, `source`.

Mặc định app trỏ tới file mẫu trong `data_sample/`.
Muốn chạy full 11.226 bài thì thay đường dẫn CSV trên sidebar.
